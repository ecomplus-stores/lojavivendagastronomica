# Widget Yourviews

Storefront plugin for yourviews reviews widgets

```js
import widgetYourviews from '@ecomplus/widget-yourviews'

widgetYourviews({
  yourviewsStoreId: 123
})
```
